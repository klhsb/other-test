require('babel-core/register');
require('./gulpfile.babel.js');
