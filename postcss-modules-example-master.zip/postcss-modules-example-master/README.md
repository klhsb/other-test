This repo contains an example for [postcss-modules](https://github.com/outpunk/postcss-modules) plugin.
